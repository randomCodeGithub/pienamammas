window.$ = window.jQuery

require('./scss/style.scss')
require('./js/script.js')