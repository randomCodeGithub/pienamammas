/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./resources/theme.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./resources/js/script.js":
/*!********************************!*\
  !*** ./resources/js/script.js ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

let toggle = false;
let expanded = false;
const menu = $(".menu-btn");
const overlayMenu = $(".overlay-menu");
const overlayArea = $(".overlay-menu__area");
const toggler = $(".toggler");
const hostName = window.location.origin;
let siteName = hostName;


if (hostName.includes("localhost")) {
  siteName += "/pienamammas";
}

$(document).ready(function () {
  // CHANGE BACKGROUND SIZE IF CURRENT PAGE NAVBAR LINK IS LESS THAN 118
  if($('a[aria-current="page"]').width() <= 118) {
    $('head').append('<style>a[aria-current="page"]:not(a.pm-btn):before{background-size:contain !important}</style>');
  }

  // PROPERTY DESCRIPTION HOVER
  $(".property-description").hover(
    function () {
      $(this).parent("div.body-small").addClass("is-hover");
      // check if block is fully in view horyzontally
      if ($(this).offset().left + 204 > $(window).width()) {
        $(this).find(".description-area").css({ left: "-13.3rem" });
        $(this).find("p").css("margin-left", "0");
        $(this).find(".background-blob").css({ transform: "scaleX(-1)" });
      } else {
        $(this).find(".description-area").css({ left: "" });
        $(this).find(".background-blob").css({ transform: "" });
        $(this).find("p").css("margin-left", "");
      }
    },
    function () {
      console.log($(".property-description").parent("div.body-small").width());
      $(this).parent("div.body-small").removeClass("is-hover");
    }
  );

  $(".reviews")
    .find(".additional-info")
    .prev(".review")
    .css("margin-bottom", "0");
  /**
   * Front page navbar change class on scroll
   */
  $(window).bind("scroll", function () {
    var navHeight = $(window).height() - 70;
    if ($(window).scrollTop() > 70) {
      $("#front-end-menu").removeClass("front-page-topmenu");
      $("#front-end-menu").addClass("not-front-page");
    } else {
      $("#front-end-menu").removeClass("not-front-page");
      $("#front-end-menu").addClass("front-page-topmenu");
    }
  });

  $(".breast-milk .dots li").addClass("dot");
  // WRAP INNER
  $(".breast-milk .dots li").wrapInner("<p class='body-small'></p>");
  $(".orange-list li, .grey-list li").wrapInner("<p class='body-small'></p>");
  $(".security-page table td").wrapInner("<p class='body-smaller'></p>");

  //ADD CLASS
  $(
    ".expert-opinion-page .col-lg-8 p, .experience-stories-page .col-lg-8 p, .useful-single .col-lg-8 p, .reviews .additional-info p, .world-experience-info .col-lg-9 p, .breast-milk-page p, .security-page .content p:not(.orange-list > p) "
  ).addClass("body-small");

  $(".world-experience-info .col-lg-9 a").addClass("orange-link");

  // ULTIMATE MEMBER
  $("#um-submit-btn, .um-editing input[type='submit'], .um-editing a.um-alt")
    .removeClass("um-button")
    .addClass("btn pm-btn pm-btn__blue");
  $(
    '.um .um-form input[type="text"], .um .um-form input[type="password"]'
  ).addClass("body-small");

  $(".um-field-checkbox-option").addClass("body-smaller");

  let privacyPolicyText = $(
    ".um-field-area .um-field-checkbox:first-child .um-field-checkbox-option"
  ).text();

  let privacyPolicyNewText = privacyPolicyText.replace(
    "šeit",
    '<a href="' +
      siteName +
      '/privatuma-politika/" class="orange-link">šeit</a>'
  );

  // $('.um-field-image').append('<div id="uploaded-photo" class="img-block" style="background-image: url(./assets/img/upload-default-photo.svg);background-repeat: no-repeat;background-position: center;"></div>')
  $(".um-field-image").append('<div class="img-upload-block"></div>');
  $(".um-field-image .img-upload-block").append(
    '<div id="uploaded-photo" class="img-block" style="background-image: url(' +
      siteName +
      '/wp-content/themes/pienamammas/assets/img/upload-default-photo.svg);background-repeat: no-repeat;background-position: center;"></div>'
  );
  $(".um-field-image .img-upload-block").append(
    '<div class="img-options d-block"></div>'
  );
  $(".um-field-image .img-upload-block .img-options")
    .append(
      '<a href="javascript:void(0);" data-modal="um_upload_single" data-modal-size="normal" data-modal-copy="1" class="body-small">Pievienot bildi</a>'
    )
    .append(
      '<div class="um-single-image-preview " data-crop="0" data-key="user-avatar"><a href="javascript:void(0);" class="body-small cancel d-block">Dzēst bildi</a></div>'
    );
  $(
    ".um-field-area .um-field-checkbox:first-child .um-field-checkbox-option"
  ).html(privacyPolicyNewText);

  $(".um-field-volume")
    .parent()
    .parent()
    .prepend(
      '<label class="body-small">Piena apjoms (atstāt tukšu, ja apjoms nav zināms)</label>'
    );
  $(".um-field-from")
    .parent()
    .parent()
    .prepend(
      '<label class="w-100 body-small">Esmu gatava dalīties ar pienu</label>'
    );

  $("#time-interval").change(function () {
    $(".um-time-interval label").removeClass("d-none");
    if (!$("#time-interval").val()) {
      $(".um-time-interval label").addClass("d-none");
    }
  });
  // if (!$("#time-interval").val()) {
  //   $(".um-time-interval label").addClass("d-none");
  // }

  // if ($("input[name=user-current-photo]").length) {
  //   $(".img-upload-block #uploaded-photo").css({
  //     "background-image":
  //       "url(" + $("input[name=user-current-photo]").val() + ")",
  //     "background-size": "cover",
  //   });
  // }

  if ($(".um-single-image-preview img").length) {
    var img = document.querySelector(".um-single-image-preview img"),
      observer = new MutationObserver((changes) => {
        changes.forEach((change) => {
          if (change.attributeName.includes("src")) {
            console.log(img.src);
            $("#uploaded-photo").css({
              "background-image": "url(" + img.src + ")",
              "background-size": "cover",
            });
          }

          if (img.getAttribute("src") == "") {
            console.log("no src");
            $("#uploaded-photo").css({
              "background-image":
                "url(" +
                siteName +
                "/wp-content/themes/pienamammas/assets/img/upload-default-photo.svg)",
              "background-size": "auto",
            });
          }
        });
      });
    observer.observe(img, { attributes: true });
  }
  

  // IF PROFILE EDIT PAGE
  if ($(".um-profile").length) {
    $(".img-options .um-single-image-preview .cancel").on("click", function () {

      $(".img-upload-block #uploaded-photo").css({
        "background-image":
          "url(" +
          siteName +
          "/wp-content/themes/pienamammas/assets/img/upload-default-photo.svg)",
        "background-size": "auto",
      });

      $('.um-field-image .img-upload-block .img-options a[data-modal="um_upload_single"]').text('Pievienot bildi');
    });

    $(".um-single-image-preview img").on("load", function () {
      $(".img-upload-block #uploaded-photo").css({
        "background-image": "url(" + $(this).attr("src") + ")",
        "background-size": "cover",
      });

      $('.um-field-image .img-upload-block .img-options a[data-modal="um_upload_single"]').text('Mainīt bildi');
      if ($(".remove-current-photo").length) {
        $(".remove-current-photo").remove();
      }
    });
  }

  $(".join.edit-profile a.remove-profile, .remove-overlay a").click(() => {
    $(".remove-overlay").toggleClass("d-flex");
  });

  
  // TIME INTERVAL FORMAT
  // let dateFromNew = dateFrom[2] + '.' + dateFrom[1] + '.' + dateFrom[0];
  $(window).load(function() {
    $( "#from-554, #to-554" ).change(function() {
      if(!($("#um_field_554_from > p").length >0)) {
        $("#um_field_554_from").append('<p class="from-format body-small position-absolute"><?php echo $formatFromDate ?></p>');
      }
      setTimeout(() => {
        let dateFrom = $(this).parent().parent().find('input[type="hidden"]').val().split('/');
        let dateFromNew = dateFrom[2] + '.' + dateFrom[1] + '.' + dateFrom[0];
        $(this).parent().parent().find('p.body-small').text(dateFromNew);
      }, 500);
    });

  })

  /**
   * Tablet, mobile menu
   */
  menu.click(function () {
    toggle = !toggle;

    if (toggle) {
      overlayMenu.addClass("open");
      toggler.addClass("open");
      overlayArea.addClass("open");
    } else {
      overlayMenu.removeClass("open");
      toggler.removeClass("open");
      overlayArea.removeClass("open");
    }
  });

  // TABLE SCROLLING
  $("#scroll-right").on("click", function () {
    let leftPos = $(this).next("#table-wrapper").scrollLeft();
    let scrollToLeft = 150;

    if ($(window).width() < 768) {
      scrollToLeft = 120;
    }

    $("#table-wrapper").animate(
      {
        scrollLeft: leftPos + scrollToLeft,
      },
      500
    );
  });

  $("#table-wrapper")
    .scroll(function (e) {
      var _this = this;
      $(this)
        .prev()
        .prev(".right-gradient")
        .css({
          opacity:
            _this.scrollWidth === _this.scrollLeft + _this.clientWidth
              ? "0"
              : "1",
        });
    })
    .scroll();

  $(".selectBox").click(function () {
    var checkboxes = document.getElementById("checkboxes");
    if (!expanded) {
      $(this).find("select").css("background-color", "#E0E5F2");
      $(this).addClass("open");
      checkboxes.style.display = "block";
      expanded = true;
    } else {
      $(this).find("select").css("background-color", "");
      $(this).removeClass("open");
      checkboxes.style.display = "none";
      expanded = false;
    }
  });

  $(".advertisements .users").on("click", ".user-current-email", function () {
    $(this).find(".user-email").addClass("d-block");
    $(this).find(".show-email").remove();
  });

  $(".data-loader").hide();

  $(".load-more-posts").click(function () {
    $("#true_loadmore").text("Ielādēšana..."); // изменяем текст кнопки

    var data = {
      action: "loadmore",
      query: true_posts,
      page: current_page,
    };

    $.ajax({
      url: ajaxurl, // обработчик
      data: data, // данные
      type: "POST", // тип запроса

      success: function (data) {
        if (data) {
          if ($(".useful-posts .posts").length) {
            $(".useful-posts .posts").append(data);
          }
          if ($(".expert-opinion-more .posts").length) {
            $(".expert-opinion-more .posts").append(data);
          }
          if ($(".experience-stories .posts").length) {
            $(".experience-stories .posts").append(data);
          }

          $("#true_loadmore").text("Ielādēt vēl");

          current_page++; // увеличиваем номер страницы на единицу

          if (current_page == max_pages) $(".load-more-posts").remove(); // если последняя страница, удаляем кнопку
        } else {
          $(".load-more-posts").remove(); // если мы дошли до последней страницы постов, скроем кнопку
        }
      },
    });
  });
});

if ($("#facts").length) {
  $("#facts")
    .on("init", function (event, slick) {
      for (var i = 0; i < slick.$slides.length; i++) {
        var $slide = $(slick.$slides[i]);
        if ($slide.hasClass("slick-current")) {
          // update DOM siblings
          $slide.prev().addClass("prev-slider");
          $slide.next().addClass("next-slider");
          break;
        }
      }
    })
    .slick({
      slidesToShow: 1,
      autoplaySpeed: 50,
      autoplay: false,
      rtl: false,
      slidesToScroll: 1,
      arrows: true,
      infinite: true,
      centerMode: true,
      variableWidth: true,
      focusOnSelect: true,
      // touchMove: true,
      draggable: false,
      prevArrow: '<span class="prev-arrow"><h1><</h1></span>',
      nextArrow: '<span class="next-arrow"><h1>></h1></span>',
    })
    .on("beforeChange", function (event, slick, currentSlide, nextSlide) {
      slick.$slides.removeClass("prev-slider").removeClass("next-slider");
      for (var i = 0; i < slick.$slides.length; i++) {
        var $slide = $(slick.$slides[i]);
        if ($slide.hasClass("slick-current")) {
          $slide.next().removeClass("next-slider");
          break;
        }
      }
    });

  $("#facts").on("afterChange", function (event, slick, direction) {
    console.log("afterChange/init", event, slick, slick.$slides);
    // remove all prev/next
    slick.$slides.removeClass("prev-slider").removeClass("next-slider");
    for (var i = 0; i < slick.$slides.length; i++) {
      var $slide = $(slick.$slides[i]);
      if ($slide.hasClass("slick-current")) {
        $slide.prev().addClass("prev-slider");
        $slide.prev().prev().removeClass("prev-slider");
        $slide.next().addClass("next-slider");
        break;
      }
    }
  });
}


/***/ }),

/***/ "./resources/scss/style.scss":
/*!***********************************!*\
  !*** ./resources/scss/style.scss ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "./resources/theme.js":
/*!****************************!*\
  !*** ./resources/theme.js ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

window.$ = window.jQuery

__webpack_require__(/*! ./scss/style.scss */ "./resources/scss/style.scss")
__webpack_require__(/*! ./js/script.js */ "./resources/js/script.js")

/***/ })

/******/ });
//# sourceMappingURL=theme.js.map