<?php

/**
 * Template Name: Pievienoties
 */

global $user_ID;
if ($user_ID) {
    $user = wp_get_current_user();
    if (in_array('administrator', (array) $user->roles)) {
        header('Location: ' . get_site_url() . '/dashboard/');
    } else {
        header('Location: ' . site_url() . '/profils');
    }
}
?>


<?php get_header();  ?>

<section class="join">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <h1>Pievienoties</h1>
                <h2>Vēlos:</h2>
                <div class="choice">
                    <a class="pm-btn pm-btn__blue-not-clicked <?php if ($_GET['mother_type'] == 'donate') echo 'pm-btn__blue-clicked' ?>
" href="<?php echo get_option("siteurl"); ?>/pievienoties/?mother_type=donate">Dāvināt pienu</a>
                    <a class="pm-btn pm-btn__blue-not-clicked <?php if ($_GET['mother_type'] == 'get') echo 'pm-btn__blue-clicked' ?>" href="<?php echo get_option("siteurl"); ?>/pievienoties/?mother_type=get">Saņemt pienu</a>
                </div>
                <?php
                if (!$_GET['mother_type']) : ?>
                    <a class="orange-link position-relative" style="z-index: 2;" href="<?php echo get_option("siteurl"); ?>/pieslegties/">
                        <h4>Pieslēgties ar jau eksistējošu profilu</h4>
                    </a>

                <?php endif ?>
            </div>
            <div class="col-lg-6 mx-auto" style="z-index: 2;">
                <?php
                // if ($_GET['mother_type'] == 'donate') {
                //     echo do_shortcode('[ultimatemember form_id="548"]');
                // } else if ($_GET['mother_type'] == 'get') {
                //     // echo 'is get';
                // }
                if ($_GET['mother_type']) {
                    echo do_shortcode('[ultimatemember form_id="548"]');
                }
                ?>
            </div>
            <?php
            if ($_GET['mother_type'] == 'get') { ?>
                <script>
                    jQuery(function() {
                        $("input:radio[name=role]").prop("checked", true);
                        // $('.um-field-radio').not('.active').find('input:radio[name=role]').prop("checked", true);
                        console.log($("input:radio[name=role]:checked").val());
                    });
                </script>

            <?php
            }
            ?>
        </div>
    </div>
</section>

<script>
    jQuery(document).ready(function() {
        $('#from-548, #to-548').css('color', 'transparent');

        $("#from-548, #to-548").on("change", function() {
            if (!($("#um_field_548_from > p, #um_field_548_to > p").length > 0)) {
                $("#um_field_548_from, #um_field_548_to").append('<p class="from-format body-small position-absolute"></p>');
            }

            setTimeout(() => {
                if ($(this).parent().parent().find('input[type="hidden"]').val()) {
                    let dateFrom = $(this).parent().parent().find('input[type="hidden"]').val().split('/');
                    let dateFromNew = dateFrom[2] + '.' + dateFrom[1] + '.' + dateFrom[0];
                    $(this).parent().parent().find('p.body-small').text(dateFromNew);

                }
            }, 500);
        });

    });
</script>

<?php get_footer(); ?>