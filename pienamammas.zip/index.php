<?php get_header(); ?>

<div class="site-content">
</div>

<?php get_footer(); ?>