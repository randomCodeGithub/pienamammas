
const config = {
  mode: 'development',
  plugins: [
  ],
  module: {
    rules: [
  	]
  }
}

module.exports = config;