<?php $quoteText = get_field('quote') ?: 'Quote text'; ?>
</div>
<div class="col-lg-9 mx-auto">
    <blockquote>
        <h3><?php echo $quoteText ?></h3>
    </blockquote>
</div>
<div class="col-lg-8 offset-lg-4">